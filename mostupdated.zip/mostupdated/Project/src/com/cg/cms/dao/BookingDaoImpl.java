package com.cg.cms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.cms.dto.Booking;
import com.cg.cms.dto.Flight;
import com.cg.cms.dto.PassengerDetail;
import com.cg.cms.dto.User;
import com.cg.cms.exception.BookingException;
import com.cg.cms.util.DatabaseConnection;





public class BookingDaoImpl implements IBookingDao {
	
	private static Logger logger= Logger.getLogger(BookingDaoImpl.class);
	Connection connection;
	public BookingDaoImpl() {
	connection= DatabaseConnection.getConnection();	
	}
	
	
	
	private int generateBookingId() throws BookingException{
			int id=0;
		try {
			Statement s= connection.createStatement();
			ResultSet rs= 
		s.executeQuery("select bookingId.nextval from dual");
		if(rs.next())
			id=rs.getInt(1);
		} catch (SQLException e) {
			throw new BookingException(e.getMessage());
		}
		return id;
	}
	
	
	
	@Override
	public Booking addBooking(Booking booking) throws BookingException {
		String sql="insert into BookingInformation values (?,?,?,?,?,?,?)";		
		try {
			int id =generateBookingId();
			PreparedStatement ps= connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2, booking.getCustEmail());
			ps.setInt(3,booking.getPassengers());
		//	ps.setString(4, booking.getClassType());
			ps.setInt(4, booking.getTotalFare());
		//	ps.setInt(6, booking.getSeatNo());
			ps.setString(5, booking.getCreditInfo());
			ps.setString(6, booking.getSrcCity());
			ps.setString(7, booking.getDestCity());
			ps.executeUpdate();
			booking.setBookingId(id);
			logger.info("Successfully Booking Added!");
		}catch (SQLException e) {
			if(e.getErrorCode()==1){
				logger.error("Booking code already exists...");
			 throw new BookingException("Booking code Already exists..!!!");
			}
			else if(e.getErrorCode()==2291){
				logger.error("Invalid Booking code ..!!");
				throw new BookingException("Invalid Booking code..!!");
			}
			else{
				logger.error(e.getMessage());
				throw new BookingException(e.getMessage());
			}
		}
		return booking;
	}
	
	@Override
	public boolean updateBooking(String custEmail,int id) throws BookingException {
		String sql="update BookingInformation set CUST_EMAIL=? where BOOKING_ID = ?";
		
		try {
			PreparedStatement pst=connection.prepareStatement(sql);
			pst.setString(1,custEmail);
			pst.setInt(2, id);
			pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BookingException("Problem in the updating details"+e.getMessage());
		}
		
		
		return true;
		
	}
	
	
	
	/*@Override
	public List<Booking> getBookingList() throws BookingException {
		String sql="Select * from BookingInformation";
		List<Booking> BookingList= new ArrayList<Booking>();
		try {
			PreparedStatement ps= connection.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int id= rs.getInt("BOOKING_ID");
				String mail=rs.getString("CUST_EMAIL");
				int passenger=rs.getInt("NO_OF_PASSENGERS");
				String classType=rs.getString("CLASS_TYPE");
				int fare=rs.getInt("TOTAL_FARE");
				int seat=rs.getInt("SEAT_NUMBER");
				String credit=rs.getString("CREDITCARDINFO");
				String src=rs.getString("SRC_CITY");
				String des=rs.getString("DEST_CITY");
				
				Booking booking= new Booking();
				booking.setBookingId(id);
				booking.setCustEmail(mail);
				booking.setPassengers(passenger);
				booking.setClassType(classType);
				booking.setTotalFare(fare);
				booking.setSeatNo(seat);
				booking.setCreditInfo(credit);
				booking.setSrcCity(src);
				booking.setDestCity(des);
				
				BookingList.add(booking);
			}
			rs.close();
			ps.close();
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BookingException(e.getMessage());
		}
		return BookingList;
	}
	
	
	*/
	
	
	@Override
	public Booking deleteBooking(int id) throws BookingException {
		
		  String sql="delete from BookingInformation where BOOKING_ID = ?";
			
		  Booking booking=new Booking();
			try {
				PreparedStatement ps= connection.prepareStatement(sql);
				ps.setInt(1, id);
				int row= ps.executeUpdate();
				if(row==1)
					booking.setBookingId(id);
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new BookingException(e.getMessage());}
			
		return booking;
	}
	
	@Override
	public List<Flight> getFlightList(String Dep_Date, String Arr_city) throws BookingException {
		String sql="Select * from FlightInformation2 where dep_date=? AND arr_city=?";
		List<Flight> FlightList= new ArrayList<Flight>();
		Statement st;
		Flight flight=new Flight();
		try {
			st = connection.createStatement();
			PreparedStatement ps= connection.prepareStatement(sql);
			ps.setString(1, Dep_Date);
			ps.setString(2, Arr_city);
			ResultSet rs=ps.executeQuery();
			
	
			
			while(rs.next())
			{
				
			
				flight.setFlightno(rs.getInt("flightno"));
				flight.setAirline(rs.getString("airline"));
				flight.setDepcity(rs.getString("dep_city"));
				flight.setArrcity(rs.getString("arr_city"));
				flight.setDepdate(rs.getString("dep_date"));
				flight.setArrdate(rs.getString("arr_date"));
				flight.setDeptime(rs.getString("dep_time"));
				flight.setArrtime(rs.getString("arr_time"));
				flight.setSeats(rs.getInt("seats"));
				flight.setFare(rs.getInt("fare"));

				FlightList.add(flight);
				//	System.out.println(FlightList);
				
		}
		}
		catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BookingException(e.getMessage());
		}
		
		
		//	System.out.println(FlightList);
		
		return FlightList;
	
	
	}
	@Override
	public String getRole(String uname, String pass) throws BookingException {
		// TODO Auto-generated method stub
		String a = "Other";
		
		String sql="SELECT role from Users where login_id=? AND password=?";
	/*connection=DatabaseConnection.getConnection();
		*/
		PreparedStatement pst;
		try {
			
			pst = connection.prepareStatement(sql);
			
			
			pst.setString(1, uname);
			pst.setString(2, pass);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				 a = rs.getString("role");
				
			}
		logger.info("Success");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());//e.printStackTrace();
		}
	
		return a;
		
		
	}
	@Override
	public List<Booking> viewBooking(int id) throws BookingException {
		  String sql="select * from BookingInformation where BOOKING_ID = ?";
			ArrayList<Booking> blist = new ArrayList<>();

		  Booking booking=new Booking();
			try {
				PreparedStatement ps= connection.prepareStatement(sql);
				ps.setInt(1, id);
				ResultSet rs=ps.executeQuery();
				while(rs.next()){
					
					booking.setBookingId(rs.getInt("booking_id"));
					booking.setCustEmail(rs.getString("cust_email"));
					booking.setPassengers(rs.getInt("no_of_passengers"));
					booking.setTotalFare(rs.getInt("total_fare"));
					booking.setCreditInfo(rs.getString("creditcard_info"));
					booking.setSrcCity(rs.getString("src_city"));
					booking.setDestCity(rs.getString("dest_city"));
					
					
					blist.add(booking);
				}
			}
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
		//	System.out.println(booking);
			
		return blist;
	}
	
/*	
	public void insertNames (int bookingid, String name , String airline ) throws BookingException
	
	{
		String sql = "insert into PassengerDetails values(?,?,?)";
		
		PreparedStatement ps;
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, bookingid);
			ps.setString(2, name);
			ps.setString(3,airline);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		
		
		
	}*/
	@Override
	public boolean updateFlightSeats(int flightno, int passengers) throws BookingException {

		//firstSeats
String sql="update FlightInformation2 set seats=seats-? where flightno = ?";
		
		try {
			PreparedStatement pst=connection.prepareStatement(sql);
			pst.setInt(1,passengers);
			pst.setInt(2,flightno);
			pst.executeUpdate();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BookingException("Problem in the updating flight seat details"+e.getMessage());
		}
		
		
		
		
	}
	///
	///
	
	
	
	@Override
	public int getFare(int flightno) throws BookingException {
		// TODO Auto-generated method stub
		int a = 0;

		String sql="SELECT fare from Flightinformation2 where flightno=?";
	/*connection=DatabaseConnection.getConnection();
		*/
		PreparedStatement pst;
		try {
			
			pst = connection.prepareStatement(sql);
			
			
			pst.setInt(1, flightno);
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				 a = rs.getInt("fare");
				
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return a;
		
		
	}
	
	
	// AMRITESH
	
	@Override
	public void PassengerDetails(int bookingid, int flightno, String PassengerName) throws BookingException
	{
		String sql="insert into PassengerInformation2 values(?,?,?)";
		PreparedStatement ps;
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, bookingid);
			ps.setString(2, PassengerName);
			ps.setInt(3,flightno);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
	
	@Override
	public int FlightOccupancy(int Flightno) throws BookingException
	{
		int a=0;
		String sql="SELECT seats FROM FlightInformation2 WHERE flightno=?";
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setInt(1, Flightno);
			ResultSet rst = pst.executeQuery();
		    rst.next();
		    a = rst.getInt(1);
		    
		    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	
		
	}
	
	
	@Override
	public List<PassengerDetail> ListAllPassengers(int flightno) throws BookingException
	{
		
		String sql = "SELECT * FROM PassengerInformation2 where flightid=?";
		ArrayList<PassengerDetail> clist = new ArrayList<>();
		
		Statement st;
		try {
			st = connection.createStatement();
			PreparedStatement pst= connection.prepareStatement(sql);
			pst.setInt(1,flightno);
			
			ResultSet rst = pst.executeQuery();
			
			
			while(rst.next()){
				
				PassengerDetail m = new PassengerDetail();
				m.setBookingid(rst.getInt("bookingid"));
				m.setPassengerName(rst.getString("passengername"));
				m.setAirlineNo(rst.getInt("flightid"));
				
				clist.add(m);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
		return clist;
	}
	
	
	
	
	//KALYANI
	
	
	
	/*updating flight time*/

	@Override
	public int updateFlightTime(int Flight_no, String Dep_time, String Arr_time) throws BookingException {

			String sql="update FlightInformation2 SET  Dep_time = ?, Arr_time = ?  where flightno = ?";

			int row=0;


			try {
				PreparedStatement ps= connection.prepareStatement(sql);
				ps.setString(1, Dep_time);
				ps.setString(2, Arr_time);
				ps.setInt(3,Flight_no );
				
				
				 row= ps.executeUpdate();
				 System.out.println(row);
				
			}
			catch (SQLException e) {
				logger.error(e.getMessage());
					throw new BookingException(e.getMessage());
			}
			 return row;
			
			}
		









	/*updating flight date*/





	@Override
	public int updateFlightDate(int Flight_no, String Dep_Date, String Arr_Date) throws BookingException {
		
		
		int row=0;

	
			String sql="update FlightInformation2 set Dep_Date = ?, Arr_Date = ?  where flightno = ?";
		
			PreparedStatement ps;
			try {
				ps = connection.prepareStatement(sql);
			
				ps.setString(1, Dep_Date);
				ps.setString(2, Arr_Date);
				ps.setInt(3,Flight_no );
				 row= ps.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
			 return row;
	
	}

			

			

	






	/* updating flight name*/

	@Override
	public int updateAirlineName(int Flight_no, String Airline) throws BookingException {

			String sql="update FlightInformation2 set Airline= ? where flightno = ?";

		

			int row=0;

			try {
				PreparedStatement ps= connection.prepareStatement(sql);
				ps.setString(1,Airline );
				ps.setInt(2,Flight_no );
				 row= ps.executeUpdate();
			
			}
			catch (SQLException e) {
				logger.error(e.getMessage());
					throw new BookingException(e.getMessage());
			}
	
			 return row;
	
	
	

}










/* retrieving info of flights based on source destination and date*/


@Override
	public List<Flight> getFlightInfoList(String  depcity, String arrcity,String depdate ) throws BookingException {
		// TODO Auto-generated method stub
		String sql="Select * from FlightInformation2 WHERE dep_city=? AND arr_city=? AND dep_date=? ";
		ArrayList<Flight> FlightInfoList= new ArrayList<Flight>();
		Flight flight=new Flight();
		try {
			PreparedStatement ps= connection.prepareStatement(sql);
			
			ps.setString(1, depcity);
			ps.setString(2, arrcity);
			ps.setString(3, depdate);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				
				flight.setFlightno(rs.getInt("flightno"));
				flight.setAirline(rs.getString("Airline"));
				flight.setDepcity(rs.getString("Dep_city"));
				flight.setArrcity(rs.getString("Arr_city"));
				flight.setDepdate(rs.getString("Dep_Date"));
				flight.setArrdate(rs.getString("Arr_Date"));
				flight.setDeptime(rs.getString("Dep_time"));
				flight.setArrtime(rs.getString("Arr_time"));
				flight.setSeats(rs.getInt("Seats"));
				flight.setFare(rs.getInt("Fare"));
				FlightInfoList.add(flight);
			} 
		}catch (SQLException e) {
				logger.error(e.getMessage());
				throw new BookingException(e.getMessage());
			}
				
		return FlightInfoList;
	}





@Override
public int getFlightId(int bookid) throws BookingException
{
	String sql="select flightid from PassengerInformation2 where bookingid=? ";
			PreparedStatement pst;
			int a=0;
	try {
		pst = connection.prepareStatement(sql);
		pst.setInt(1, bookid);
		ResultSet rst = pst.executeQuery();
	    rst.next();
	    a = rst.getInt(1);
	    
	    
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return a;	
			
			
}

@Override
public boolean addFlightSeats(int flightno,int passengers) throws BookingException
	
{
	String sql="update FlightInformation2 set seats=seats+? where flightno = ?";
	
	
	
	
	try {
		PreparedStatement pst=connection.prepareStatement(sql);
		pst.setInt(1,passengers);
		pst.setInt(2,flightno);
		pst.executeUpdate();
		System.out.println("hi");
		
		return true;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		throw new BookingException("Problem in the updating flight seat details"+e.getMessage());
	}
	
/*	String sql="update FlightInformation2 set seats=seats-? where flightno = ?";
	
	try {
		PreparedStatement pst=connection.prepareStatement(sql);
		pst.setInt(1,passengers);
		pst.setInt(2,flightno);
		pst.executeUpdate();
		return true;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		throw new BookingException("Problem in the updating flight seat details"+e.getMessage());
	}
	*/
	
	
	
	
}
@Override
	public int deleteFromPassenger(int bookid) throws BookingException
	{
	String sql="delete from PassengerInformation2 where bookingid=?" ;
	 int row=0;
		try {
			PreparedStatement ps= connection.prepareStatement(sql);
			ps.setInt(1, bookid);
		  row= ps.executeUpdate();
			System.out.println(row);
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BookingException(e.getMessage());}
		
	return row;
	
	
	
	}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


