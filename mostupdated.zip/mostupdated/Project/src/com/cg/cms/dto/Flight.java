package com.cg.cms.dto;
import java.util.Date;

	public class Flight {
		
		private int flightno;
	    private String airline; 
		private String  depcity;
		private String arrcity;
		private String depdate;
		private String arrdate; 
		private String deptime;
	    private String arrtime;
		private int seats;
		private int fare;

		
		public int getFlightno() {
			return flightno;
		}
		public void setFlightno(int flightno) {
			this.flightno = flightno;
		}
		public String getAirline() {
			return airline;
		}
		public void setAirline(String airline) {
			this.airline = airline;
		}
		public String getDepcity() {
			return depcity;
		}
		public void setDepcity(String depcity) {
			this.depcity = depcity;
		}
		public String getArrcity() {
			return arrcity;
		}
		public void setArrcity(String arrcity) {
			this.arrcity = arrcity;
		}
		public String getDepdate() {
			return depdate;
		}
		public void setDepdate(String depdate) {
			this.depdate = depdate;
		}
		public String getArrdate() {
			return arrdate;
		}
		public void setArrdate(String arrdate) {
			this.arrdate = arrdate;
		}
		public String getDeptime() {
			return deptime;
		}
		public void setDeptime(String deptime) {
			this.deptime = deptime;
		}
		public String getArrtime() {
			return arrtime;
		}
		public void setArrtime(String arrtime) {
			this.arrtime = arrtime;
		}
		
		
		
		
		public int getSeats() {
			return seats;
		}
		public void setSeats(int seats) {
			this.seats = seats;
		}
		public int getFare() {
			return fare;
		}
		public void setFare(int fare) {
			this.fare = fare;
		}
		@Override
		public String toString() {
			return "Flight [flightno=" + flightno + ", airline=" + airline
					+ ", depcity=" + depcity + ", arrcity=" + arrcity
					+ ", depdate=" + depdate + ", arrdate=" + arrdate
					+ ", deptime=" + deptime + ", arrtime=" + arrtime
					+ ", seats=" + seats + ", fare=" + fare + "]";
		}
		
		
		
}


