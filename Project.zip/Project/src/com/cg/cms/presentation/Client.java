package com.cg.cms.presentation;


import java.util.List;
import java.util.Scanner;

import com.cg.cms.dto.Booking;
import com.cg.cms.dto.Flight;
import com.cg.cms.dto.PassengerDetail;
import com.cg.cms.exception.BookingException;
import com.cg.cms.service.BookingServiceImpl;
import com.cg.cms.service.IBookingService;


//import com.cg.mobile.validation.DataValidator;

public class Client {
	
	//Main Method
	
	public static void main(String[] args) throws BookingException {
		IBookingService src = new BookingServiceImpl();
	
		Booking booking= new Booking();
		Scanner sc = new Scanner(System.in);
		Outer:
		do{
			System.out.println("LOGIN");
			System.out.println("Enter your username ");
			String uname = sc.next();
			System.out.println("Enter password");
			String pass = sc.next();
			String role = src.getRole(uname,pass);
			System.out.println(role);
			if(role.equals("AE"))
			{
				do
				{
				System.out.println("AIRLINE EXECUTIVE MENU\n1.View Flight Occupancy\n2.Exit ");
				int choice = sc.nextInt();
				
				switch(choice)
				{
				case 1:
					
					System.out.println("Enter airline numnber");
					int value = src.FlightOccupancy(sc.nextInt());
					if(value==0)
					{
						System.out.println("No seats available");
					}
					else
					{
						System.out.println(value+" seats available out of 100");
					}
					
					break;
				case 2:
					continue Outer;
					
				default:
					System.out.println("invalid input");
				
				
				}
				
			}while(true);
			}
			
			
			else if(role.equals("User"))
			{
				
				do {
					
					
					System.out.println("USER MENU\n1.Book Flight Ticket\n2.View Reservation Details\n3.Update Email\n4.Cancel Booking\n5.Exit");
					int choice1=sc.nextInt();
					switch(choice1)
					{
					
					case 1:
						System.out.println("Enter Source");
						String depcity = sc.next();
						System.out.println("Enter Destintion");
						String arrcity=sc.next();
						System.out.println("Enter date of journey");
						String depdate=sc.next();
						
						System.out.println("Following flights are available:\n");
						
						List<Flight>  flist;
						flist = src.getFlightInfoList(depcity,arrcity,depdate );
						
						for (Flight flight : flist) {
							System.out.println(flight);
						}
						
						System.out.println("Enter flight number ");
						int flightno = sc.nextInt();
						System.out.println("Enter your email ");
						String email=sc.next();
						
						System.out.println("Enter total passengers ");
						int passengers = sc.nextInt();
						System.out.println("Enter Credit card info ");
						String credit_card=sc.next();
						
						int total_fare= src.getFare(flightno)*passengers;
						booking.setSrcCity(depcity);
						booking.setDestCity(arrcity);
						booking.setCustEmail(email);
						booking.setPassengers(passengers);
						booking.setCreditInfo(credit_card);
						booking.setTotalFare(total_fare);
						src.addBooking(booking);
						System.out.println("Enter your passenger name(s):");
						for(int i=1 ; i<=passengers ; i++)
						{
							System.out.println("Enter Name"+i+":");
							String name=sc.next();
							src.PassengerDetails(booking.getBookingId(), flightno, name);
							
							
						}
						System.out.println("Booking Successful with booking id:"+booking.getBookingId());
						System.out.println("Your total fare generated :"+total_fare);
						src.updateFlightSeats(flightno, passengers);
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						break;
					case 2:
						System.out.println("Enter booking id ");
						int id = sc.nextInt();
						List<Booking> blist= src.viewBooking(id);
						for (Booking b : blist) {
							System.out.println(b);
						}
						
						
						
					
						
						
						break;
					case 3:
						System.out.println("Enter booking id ");
						int bid = sc.nextInt();
						System.out.println("Enter new email");
						
						
						String Email= sc.next();
						if(src.updateBooking(Email,bid)==true)
						{
							System.out.println("Updated Successfully ");
						}
						else {
							System.out.println("Problem in updating ");
						}
						
						
						break;
					case 4:
						System.out.println("Enter booking id");
						int bookid=sc.nextInt();
						src.deleteBooking(bookid);
						
					
						int f1=src.getFlightId(bookid);
						int passenger=src.deleteFromPassenger(bookid);
						src.addFlightSeats(f1, passenger);
						System.out.println(f1);
						System.out.println(passenger);
						System.out.println("Booking Canceled Successfully");
						
						
		
						// add seats to flightinfo table
						//call func to remove that passenger from passenger table
						break;
					case 5:
						
						
						continue Outer;
						
					default:
						System.out.println("Invalid Choice");
					
					
					}
			
					
					
					
				}while(true);
				
			
			}
			
			
			else if(role.equals("Admin"))
			{
				
				do{
					

					System.out.println("ADMIN MENU");
					System.out.println("1.Update Flight Time ");
					System.out.println("2.Update Flight Date ");
					System.out.println("3.Update Flight Name ");
					System.out.println("4.View List of flights based on date and destination");
				
					System.out.println("5.View passenger list of a specific flight ");
					System.out.println("6.Exit");
					System.out.println("Enter choice ");
					int ch=sc.nextInt();
					switch(ch)
					{
					
					case 1:
						
						System.out.println("Enter flight no");
						int id=sc.nextInt();
						System.out.println("Enter New departure time");
						String dt=sc.next();
						System.out.println("Enter New arrival time");
						String ar=sc.next();
						
						if(src.updateFlightTime(id, dt, ar)>0)
						{
							System.out.println("Update Successful");
						}
						else
						{
							System.out.println("Update UnSuccessful");
						}
							
							
						
						break;
					case 2:
						
						System.out.println("Enter flight no");
						int id1=sc.nextInt();
						System.out.println("Enter New departure date");
						String dt1=sc.next();
						System.out.println("Enter New arrival date");
						String ar1=sc.next();
						
						if(src.updateFlightDate(id1, dt1, ar1)>0)
						{
							System.out.println("Update Successful");
						}
						else
						{
							System.out.println("Update UnSuccessful");
						}
						
						
						
						
						
						
						
						break;
					case 3:
						
						System.out.println("Enter flight no");
						int id2=sc.nextInt();
						System.out.println("Enter New Airline name");
						String dt2=sc.next();
					
						
						if(src.updateAirlineName(id2, dt2)>0)
						{
							System.out.println("Update Successful");
						}
						else
						{
							System.out.println("Update UnSuccessful");
						}
						
						
						
						break;
					case 4:
						
						System.out.println("Enter departure date");
						String id3=sc.next();
						System.out.println("Enter destination city");
						String dt3=sc.next();
						List<Flight> blist= src.getFlightList(id3, dt3);
						for (Flight f : blist) {
							System.out.println(f);
						}
						
						
						
						break;
					case 5:
						System.out.println("Enter flight no");
						int id4=sc.nextInt();
						
						List<PassengerDetail> plist=src.ListAllPassengers(id4);
						for (PassengerDetail p : plist) {
							System.out.println(p);
						}
						
						
						
						break;
					case 6:
						continue Outer;
						
					default:
						System.out.println("Invalid Choice");
					
					
					
					
					
					
					
					
					}
					
					
					
				}while(true);
				
				
				
				
					
				
				
			}
			
			else {
				
				System.out.println("Invalid User ");
				continue Outer;
			}
			
		}while(true);
		
		
		
		
	
		
		
			
	}//main closed
}
		
		
		
		
		
		
		
		
		
		/*
		Logger logger=Logger.getRootLogger();
		PropertyConfigurator.configure("./resources/log4j.properties");
		Booking booking=new Booking();
	IBookingService service=new BookingServiceImpl();
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter choice : \n1. Insert Booking  \n2. Update Booking \n3. View Details of Booking "
			+ "\n4. Delete Booking");
	int ch=sc.nextInt();
	switch(ch){
	
	
	case 1: //case1:
	    {
	
		System.out.println("Enter Customer Email Id : ");
		String mailId= sc.next();
		System.out.println("Number of Passengers : ");
		int passengers=sc.nextInt();
		System.out.println("Class Type : Business/Economy");
		String classType= sc.next();
		String str1="Business",str2="Economy";
		if(classType.equalsIgnoreCase(str1)||classType.equalsIgnoreCase(str2))
		{
			
		}
		else
		{
			System.out.println("Invalid class");
			break;
		}
		System.out.println("Enter Seat Number : ");
		int seat=sc.nextInt();
		System.out.println("Enter Fare : ");
		int fare=sc.nextInt();
		System.out.println("Enter Credit Card Number : ");
		String credit= sc.next();
		System.out.println("Enter Source City : ");
		String src= sc.next();
		System.out.println("Enter Destination City : ");
		String des= sc.next();

		booking.setCustEmail(mailId);
		booking.setPassengers(passengers);
		booking.setClassType(classType);
		booking.setTotalFare(fare);
		booking.setSeatNo(seat);
		booking.setCreditInfo(credit);
		booking.setSrcCity(src);
		booking.setDestCity(des);
		
		
		try {
			
			Booking s1=service.addBooking(booking);
			logger.info("Booking added to DB..."+booking.getBookingId());
			System.out.println("Booking added to DB..."+booking.getBookingId());
			}
			
			 catch (BookingException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());}
		break;
	    } // case 1 closed
		
	      
	case 2:{
		
		System.out.println("Enter Booking Id : ");
		int id=sc.nextInt();
		System.out.println("Enter No Of Passengers : ");
		int passengers=sc.nextInt();
		System.out.println("Enter Class Type : ");
		String classType=sc.next();
		System.out.println("Enter Seats : ");
		int seats=sc.nextInt();
		System.out.println("Enter Fare : ");
		int fare=sc.nextInt();
		System.out.println("Enter Credid Card Number : ");
		String creditCard=sc.next();
		System.out.println("Enter Source City : ");
		String srcCity=sc.next();
		System.out.println("Enter Destination City : ");
		String deptCity=sc.next();
		
		try {
			Booking s1=service.updateBooking(id, passengers, classType, fare, seats, creditCard, srcCity, deptCity);
			if(s1.getBookingId()!=0)
				{
				logger.info("Booking updated ");
				System.out.println("Booking updated ");
				}
			else{
				logger.error("Booking not found..!!!");
				System.out.println("Booking not found..!!!");
		}} catch (BookingException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		
		break;
	}//case 2 closed
	
	case 3:{
		try {
			List<Booking> list=service.getBookingList();	
		    
		    if(list.size()==0)
		    {
		    	logger.error("No Booking available...");
		    	System.out.println("No Booking available...");
		    }else{
		    	for(Booking s: list){
		    		System.out.println(s.getBookingId()+" "+s.getCustEmail()+" "+ s.getPassengers()+" "
		    	+s.getClassType()+" "+ s.getTotalFare()+" "+s.getSeatNo()+" "+s.getCreditInfo()+" "
		    				+s.getSrcCity()+" "+s.getDestCity());
		    	}
		    	
		    }
		    
		} catch (BookingException e) {
			logger.error(e.getMessage());
		System.out.println(e.getMessage());
		}
		break;
		
	}//case 3 closed
	
	case 4:{
		System.out.println("Enter Booking Id : ");
		int id=sc.nextInt();
		
		try {
			Booking s1=service.deleteBooking(id);
			if(s1.getBookingId()!=0)
			{
				logger.info("Booking with BookingId = "+s1.getBookingId() +"deleted ");
				System.out.println("Booking with BookingId = "+s1.getBookingId() +"deleted ");
			}
			else
			{
				logger.error("Booking not found..!!!");
				System.out.println("Booking not found..!!!");
			}
		} 
		catch (BookingException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		break;
	}//case 4 closed
	
	case 5:{
		try {
			List<Flight> list=service.getFlightList();	
		    
		    if(list.size()==0)
		    {
		    	logger.error("No flights are available...");
		    	System.out.println("No flights are available");
		    }
		    else
		    {
		    	for(Flight f: list){
System.out.println(f.getFlightno()+" "+f.getAirline()+" "+f.getDepcity()+" "+f.getArrcity()+" "+f.getDepdate()+" "+
	f.getArrdate()+" "+f.getDeptime()+" "+f.getArrtime());	    
		    	}
		    	
		    }
		    
		} catch (BookingException e) {
			logger.error(e.getMessage());
		System.out.println(e.getMessage());
		}
		break;
		
	}
	
	default:
		System.out.println("Enter correct choice");
	//default close
		
	}//switch closed
	
*/	
	//class closed
	

