package com.cg.cms.service;

import java.util.List;

import com.cg.cms.dto.Booking;
import com.cg.cms.dto.Flight;
import com.cg.cms.dto.PassengerDetail;
import com.cg.cms.dto.User;
import com.cg.cms.exception.BookingException;

public interface IBookingService {
	public Booking addBooking(Booking booking) throws BookingException;//
	public boolean updateBooking(String custEmail,int id) throws BookingException;//
	//public List<Booking> getBookingList() throws BookingException;
	public Booking deleteBooking(int id) throws BookingException;//
	public List<Flight> getFlightList(String Dep_Date, String Arr_city) throws BookingException;//
	
	public String getRole(String uname,String pass) throws BookingException;//
	
	public List<Booking> viewBooking(int id) throws BookingException;//
	//public void insertNames (int bookingid, String name , String airline ) throws BookingException;
	public boolean updateFlightSeats(int flightno, int passengers) throws BookingException;//
	public int getFare(int flightno) throws BookingException;//
	
	//AMRITESH
	public void PassengerDetails(int bookingid, int flightno, String PassengerName) throws BookingException;//
	public int FlightOccupancy(int Flightno) throws BookingException;//
	public List<PassengerDetail> ListAllPassengers(int flightno) throws BookingException;//
	
	//KALYANI
	public int updateFlightTime(int Flight_no, String Dep_time, String Arr_time) throws BookingException ;
	public int updateFlightDate(int Flight_no, String Dep_Date, String Arr_Date) throws BookingException;//
	public int updateAirlineName(int Flight_no, String Airline) throws BookingException ;//
	public List<Flight> getFlightInfoList(String  depcity, String arrcity,String depdate ) throws BookingException;	//

	public int getFlightId(int bookid) throws BookingException;
	public boolean addFlightSeats(int flightno,int passengers) throws BookingException;
	public int deleteFromPassenger(int bookid) throws BookingException;
}
